
Execute : gcc -lm kdtree_final.c
Run 	: ./a.out

Example:
Input:

Dimensions : 100
number of points : 10000
number of clusters : 128 

This generates 100 * 10000 total points with 128 final clusters(leaf clusters if u imagine it as a tree)
